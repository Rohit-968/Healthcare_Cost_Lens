import matplotlib.pyplot as plt
import numpy as np

# 1. Feature Importance Plot (Based on your latest Spark output)
features = ["Benefit Count", "Submitted Charge", "State", "Specialty"]
importances = [0.0068, 0.9622, 0.0299, 0.0009]

plt.figure(figsize=(10, 5))
plt.barh(features, importances, color='teal')
plt.xlabel('Importance Score')
plt.title('Random Forest: Features Driving Medicare Payments')
plt.savefig('feature_importance.png')
plt.show()

# 2. K-Means Elbow Plot (Based on your previous script logs)
# Values: k=2: 4402633, k=3: 3105788, k=4: 2548810, k=5: 2213791, k=6: 1891550
ks = [2, 3, 4, 5, 6]
costs = [4402633, 3105788, 2548810, 2213791, 1891550]

plt.figure(figsize=(10, 5))
plt.plot(ks, costs, 'bx-')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Training Cost (WSSSE)')
plt.title('Elbow Method for Optimal k (K-Means)')
plt.savefig('elbow_plot.png')
plt.show()
