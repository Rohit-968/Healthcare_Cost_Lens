from pyspark.sql import SparkSession

# Initialize Spark Session
spark = SparkSession.builder.appName("Q5-EntityAnalysis").getOrCreate()

# Load processed data with TAB separator (\t)
df = spark.read.option("sep", "\t").csv("hdfs://namenode:9000/medicare/processed/part-*.csv") \
    .toDF("npi","proc","desc","benes","charge","pay","state","year","spec","ent")

# Prepare for SQL analysis
df.createOrReplaceTempView("medicare")

# Execute Query: Entity Disparity Analysis
result = spark.sql("""
    SELECT ent, COUNT(DISTINCT npi) as provider_count, AVG(cast(pay as double)) as avg_reimbursement 
    FROM medicare 
    GROUP BY ent
""")

# Save results to HDFS
result.write.mode("overwrite").csv("hdfs://namenode:9000/medicare/results/q5_entity_analysis")
print("Q5 Entity Analysis results saved successfully.")
spark.stop()
