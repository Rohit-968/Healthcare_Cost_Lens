billing = LOAD "/medicare/raw/provider_service.csv"
    USING PigStorage(",")
    AS (npi:chararray, last_name:chararray, first_name:chararray,
        mi:chararray, credentials:chararray, entity_code:chararray,
        st1:chararray, st2:chararray, city:chararray, state:chararray,
        state_fips:chararray, zip:chararray, ruca:chararray,
        ruca_desc:chararray, country:chararray, provider_type:chararray,
        medicare_ind:chararray, hcpcs_cd:chararray, hcpcs_desc:chararray,
        drug_ind:chararray, place_of_svc:chararray, tot_benes:chararray,
        tot_srvcs:chararray, tot_bene_day:chararray,
        avg_submitted_charge:chararray, avg_allowed_amt:chararray,
        avg_medicare_payment:chararray, avg_stdz_amt:chararray);
billing_no_header = FILTER billing BY npi != "Rndrng_NPI";
billing_clean = FILTER billing_no_header BY
    tot_benes != "" AND avg_medicare_payment != "";
billing_typed = FOREACH billing_clean GENERATE
    npi,
    LOWER(TRIM(provider_type)) AS provider_type,
    hcpcs_cd AS proc_code,
    LOWER(TRIM(hcpcs_desc)) AS description,
    (int)tot_benes AS bene_count,
    (float)avg_submitted_charge AS submitted_charge,
    (float)avg_medicare_payment AS medicare_payment,
    state AS state,
    place_of_svc AS place_of_svc,
    2021 AS year;
npi_reg = LOAD "/medicare/raw/nppes_npi.csv"
    USING PigStorage(",")
    AS (npi:chararray, specialty:chararray,
        entity_type:chararray, npi_state:chararray);
npi_no_header = FILTER npi_reg BY npi != "npi";
enriched = JOIN billing_typed BY npi LEFT OUTER, npi_no_header BY npi;
final = FOREACH enriched GENERATE
    billing_typed::npi AS npi,
    proc_code, description,
    bene_count, submitted_charge,
    medicare_payment, state, year,
    npi_no_header::specialty AS specialty,
    npi_no_header::entity_type AS entity_type;
STORE final INTO "/medicare/processed/" USING PigStorage("	");
