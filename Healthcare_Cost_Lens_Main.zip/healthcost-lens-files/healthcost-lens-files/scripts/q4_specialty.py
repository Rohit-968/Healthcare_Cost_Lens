from pyspark.sql import SparkSession

# Initialize Spark Session
spark = SparkSession.builder.appName("Q4-SpecialtyGrowth").getOrCreate()

# Load processed data with TAB separator (\t)
df = spark.read.option("sep", "\t").csv("hdfs://namenode:9000/medicare/processed/part-*.csv") \
    .toDF("npi","proc","desc","benes","charge","pay","state","year","spec","ent")

# Prepare for SQL analysis
df.createOrReplaceTempView("medicare")

# Execute Query: Specialty Growth Trends
result = spark.sql("""
    SELECT spec, year, AVG(cast(pay as double)) as avg_payout 
    FROM medicare 
    GROUP BY spec, year 
    ORDER BY avg_payout DESC
""")

# Save results to HDFS
result.write.mode("overwrite").csv("hdfs://namenode:9000/medicare/results/q4_specialty_growth")
print("Q4 Specialty Growth results saved successfully.")
spark.stop()
