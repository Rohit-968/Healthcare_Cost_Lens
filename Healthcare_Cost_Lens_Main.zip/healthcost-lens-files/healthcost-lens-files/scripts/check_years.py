from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder.appName("Data-Verification").getOrCreate()

# Load processed data with TAB separator
# Column index 7 is the year according to your query logic
df = spark.read.option("sep", "\t").csv("hdfs://namenode:9000/medicare/processed/")

print("\n=== Unique Years in Processed Data ===")
df.select(col("_c7").alias("year")).distinct().orderBy("year").show()

spark.stop()
