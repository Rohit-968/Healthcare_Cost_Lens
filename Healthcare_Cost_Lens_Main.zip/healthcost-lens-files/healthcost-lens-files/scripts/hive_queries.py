# -*- coding: utf-8 -*-
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder \
    .appName("HealthCostLens-Queries") \
    .config("spark.hadoop.fs.defaultFS", "hdfs://namenode:9000") \
    .getOrCreate()
spark.sparkContext.setLogLevel("WARN")

print("Loading processed data...")
df = spark.read.option("header", False).option("sep", "\t") \
    .csv("hdfs://namenode:9000/medicare/processed/")

df = df.toDF("npi","proc_code","description",
             "bene_count","submitted_charge","medicare_payment",
             "state","year","specialty","entity_type") \
       .withColumn("bene_count",       col("bene_count").cast("int")) \
       .withColumn("submitted_charge", col("submitted_charge").cast("float")) \
       .withColumn("medicare_payment", col("medicare_payment").cast("float")) \
       .withColumn("year",             col("year").cast("int"))

df.createOrReplaceTempView("medicare")
print("Registered temp view: {} rows".format(df.count()))

print("\nAvgerage Medicare payment by state (top 30)")
q1 = spark.sql("""
    SELECT state, proc_code,
           ROUND(AVG(medicare_payment), 2) AS avg_payment,
           COUNT(*) AS provider_count
    FROM medicare
    GROUP BY state, proc_code
    ORDER BY avg_payment DESC
    LIMIT 30
""")
q1.show(30, truncate=False)
q1.write.mode("overwrite").option("header", True) \
   .csv("hdfs://namenode:9000/medicare/results/q1_payment_by_state/")

print("\nBilling outliers Z-score > 2 (Fixed)")
q2 = spark.sql("""
    SELECT npi, proc_code, state, submitted_charge,
           ROUND(avg_charge, 2) AS avg_charge,
           ROUND(z_score, 2) AS z_score
    FROM (
        SELECT npi, proc_code, state, submitted_charge,
               avg_val AS avg_charge,
               (submitted_charge - avg_val) / std_val AS z_score
        FROM (
            SELECT npi, proc_code, state, submitted_charge,
                   AVG(submitted_charge) OVER (PARTITION BY proc_code) AS avg_val,
                   STDDEV_SAMP(submitted_charge) OVER (PARTITION BY proc_code) AS std_val,
                   COUNT(*) OVER (PARTITION BY proc_code) AS proc_count
            FROM medicare
        ) sub
        -- Only calculate for procedures with at least 2 records to avoid NULL stddev
        WHERE proc_count > 1 AND std_val > 0
    ) t
    WHERE ABS(z_score) > 2
    ORDER BY z_score DESC
    LIMIT 30
""")
q2.show(30, truncate=False)
q2.write.mode("overwrite").option("header", True) \
   .csv("hdfs://namenode:9000/medicare/results/q2_outliers/")

print("\nBeneficiary-to-provider ratio by state and specialty (top 30)")
q3 = spark.sql("""
    SELECT state, specialty,
           SUM(bene_count)          AS total_benes,
           COUNT(DISTINCT npi)      AS provider_count,
           ROUND(SUM(bene_count) / COUNT(DISTINCT npi), 0) AS bene_per_provider
    FROM medicare
    WHERE specialty IS NOT NULL AND specialty != ''
    GROUP BY state, specialty
    ORDER BY bene_per_provider DESC
    LIMIT 30
""")
q3.show(30, truncate=False)
q3.write.mode("overwrite").option("header", True) \
   .csv("hdfs://namenode:9000/medicare/results/q3_access_gap/")

print("\nProcedure Cost Disparity (Charge vs. Payout)")
q4 = spark.sql("""
    SELECT proc_code, 
           ROUND(AVG(submitted_charge), 2) AS avg_charge, 
           ROUND(AVG(medicare_payment), 2) AS avg_payment,
           ROUND(AVG(submitted_charge) - AVG(medicare_payment), 2) AS unpaid_amount
    FROM medicare
    GROUP BY proc_code
    ORDER BY avg_payment DESC
    LIMIT 50
""")
q4.show(50, truncate=False)
q4.write.mode("overwrite").option("header", True).csv("hdfs://namenode:9000/medicare/results/q4_yoy_trend/")

print("\nTop specialties by Medicare payment volume (top 30)")
q5 = spark.sql("""
    SELECT specialty,
           COUNT(DISTINCT npi)             AS provider_count,
           SUM(bene_count)                 AS total_benes,
           ROUND(AVG(medicare_payment), 2) AS avg_payment,
           ROUND(SUM(medicare_payment * bene_count), 0) AS total_payment_volume
    FROM medicare
    WHERE specialty IS NOT NULL AND specialty != ''
    GROUP BY specialty
    ORDER BY total_payment_volume DESC
    LIMIT 30
""")
q5.show(30, truncate=False)
q5.write.mode("overwrite").option("header", True) \
   .csv("hdfs://namenode:9000/medicare/results/q5_specialty_volume/")

print("\nAll 5 queries complete. Results in /medicare/results/")
spark.stop()
