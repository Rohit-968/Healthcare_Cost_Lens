# -*- coding: utf-8 -*-
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, sum as spark_sum, countDistinct
from pyspark.ml.feature import VectorAssembler, StandardScaler
from pyspark.ml.clustering import KMeans

spark = SparkSession.builder \
    .appName("HealthCostLens-KMeans") \
    .config("spark.hadoop.fs.defaultFS", "hdfs://namenode:9000") \
    .getOrCreate()
spark.sparkContext.setLogLevel("WARN")

print("Loading processed data...")
df = spark.read.option("header", False).option("sep", "\t") \
    .csv("hdfs://namenode:9000/medicare/processed/") \
    .toDF("npi","proc_code","description","bene_count","submitted_charge",
          "medicare_payment","state","year","specialty","entity_type") \
    .withColumn("bene_count",       col("bene_count").cast("float")) \
    .withColumn("submitted_charge", col("submitted_charge").cast("float")) \
    .withColumn("medicare_payment", col("medicare_payment").cast("float"))

print("Building provider-level feature vectors...")
provider_features = df.groupBy("npi").agg(
    spark_sum("bene_count").alias("total_benes"),
    avg("submitted_charge").alias("avg_charge"),
    avg("medicare_payment").alias("avg_payment"),
    countDistinct("proc_code").alias("distinct_procs")
).na.drop()

print("Provider count: {}".format(provider_features.count()))

assembler = VectorAssembler(
    inputCols=["total_benes","avg_charge","avg_payment","distinct_procs"],
    outputCol="features"
)
assembled = assembler.transform(provider_features)

scaler = StandardScaler(inputCol="features", outputCol="scaled_features",
                        withMean=True, withStd=True)
scaled = scaler.fit(assembled).transform(assembled)

print("\nElbow method (WSSSE by k):")
for k in range(2, 9):
    km = KMeans(featuresCol="scaled_features", k=k, seed=42, maxIter=20)
    model = km.fit(scaled)
    wssse = model.computeCost(scaled)
    print("  k={}: WSSSE={:.2f}".format(k, wssse))

k_final = 4
print("\nFitting final model with k={}...".format(k_final))
km_final = KMeans(featuresCol="scaled_features", k=k_final, seed=42, maxIter=30)
model_final = km_final.fit(scaled)
clustered = model_final.transform(scaled)

print("\nCluster sizes:")
clustered.groupBy("prediction").count().orderBy("prediction").show()

print("\nCluster centroids (total_benes, avg_charge, avg_payment, distinct_procs):")
for i, center in enumerate(model_final.clusterCenters()):
    print("  Cluster {}: total_benes={:.1f}  avg_charge={:.1f}  avg_payment={:.1f}  distinct_procs={:.1f}".format(
        i, center[0], center[1], center[2], center[3]))

print("\nCluster profile summary:")
clustered.groupBy("prediction").agg(
    avg("total_benes").alias("avg_total_benes"),
    avg("avg_charge").alias("avg_submitted_charge"),
    avg("avg_payment").alias("avg_medicare_payment"),
    avg("distinct_procs").alias("avg_distinct_procs")
).orderBy("prediction").show()

clustered.select("npi","total_benes","avg_charge","avg_payment",
                 "distinct_procs","prediction") \
    .write.mode("overwrite").option("header", True) \
    .csv("hdfs://namenode:9000/medicare/clusters/")

print("Clusters written to /medicare/clusters/")
spark.stop()
