# -*- coding: utf-8 -*-
from pyspark.sql import SparkSession
from pyspark.ml import Pipeline
from pyspark.ml.feature import VectorAssembler, StringIndexer
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator

spark = SparkSession.builder \
    .appName("HealthCostLens-RandomForest") \
    .getOrCreate()
spark.sparkContext.setLogLevel("WARN")

# Load data - Using '\t' as the separator commonly used in Hadoop/Pig outputs
# If your 'cat' command above showed commas, change "\t" back to ","
df = spark.read.option("header", "false").option("sep", "\t") \
    .csv("hdfs://namenode:9000/medicare/processed/part-*.csv")

# Only proceed if we have enough columns to rename
if len(df.columns) == 10:
    df = df.toDF("npi","proc_code","description","bene_count","submitted_charge",
              "medicare_payment","state","year","specialty","entity_type")
else:
    print(f"Error: Found {len(df.columns)} columns. Trying comma separator instead...")
    df = spark.read.option("header", "false").option("sep", ",") \
        .csv("hdfs://namenode:9000/medicare/processed/part-*.csv") \
        .toDF("npi","proc_code","description","bene_count","submitted_charge",
              "medicare_payment","state","year","specialty","entity_type")

# Data Cleaning
df = df.withColumn("bene_count", df["bene_count"].cast("double")) \
       .withColumn("submitted_charge", df["submitted_charge"].cast("double")) \
       .withColumn("medicare_payment", df["medicare_payment"].cast("double")) \
       .dropna()

# Indexing and Assembly
state_indexer = StringIndexer(inputCol="state", outputCol="state_index", handleInvalid="skip")
spec_indexer = StringIndexer(inputCol="specialty", outputCol="spec_index", handleInvalid="skip")

assembler = VectorAssembler(
    inputCols=["bene_count", "submitted_charge", "state_index", "spec_index"],
    outputCol="features"
)

# Model configuration
rf = RandomForestRegressor(labelCol="medicare_payment", 
                           featuresCol="features", 
                           numTrees=20, 
                           maxBins=100)

pipeline = Pipeline(stages=[state_indexer, spec_indexer, assembler, rf])
train_data, test_data = df.randomSplit([0.8, 0.2], seed=42)

print("Training Random Forest model...")
model = pipeline.fit(train_data)

# Evaluation
predictions = model.transform(test_data)
rmse = RegressionEvaluator(labelCol="medicare_payment", metricName="rmse").evaluate(predictions)
r2 = RegressionEvaluator(labelCol="medicare_payment", metricName="r2").evaluate(predictions)

print(f"\n=== Model Results ===\nRMSE: {rmse:.2f}\nR2: {r2:.4f}")
print(f"Feature Importances: {model.stages[-1].featureImportances}")

spark.stop()
