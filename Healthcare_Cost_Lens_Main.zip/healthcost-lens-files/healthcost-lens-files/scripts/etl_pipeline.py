
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lower, trim, lit

spark = SparkSession.builder     .appName("HealthCostLens-ETL")     .config("spark.hadoop.fs.defaultFS", "hdfs://namenode:9000")     .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
print("Loading provider_service.csv...")

billing = spark.read.option("header", True)     .option("inferSchema", False)     .csv("hdfs://namenode:9000/medicare/raw/provider_service.csv")

billing_clean = billing.filter(
    (col("Tot_Benes").isNotNull()) &
    (col("Avg_Mdcr_Pymt_Amt").isNotNull()) &
    (col("Tot_Benes") != "") &
    (col("Avg_Mdcr_Pymt_Amt") != "")
)

billing_typed = billing_clean.select(
    col("Rndrng_NPI").alias("npi"),
    lower(trim(col("Rndrng_Prvdr_Type"))).alias("provider_type"),
    col("HCPCS_Cd").alias("proc_code"),
    lower(trim(col("HCPCS_Desc"))).alias("description"),
    col("Tot_Benes").cast("int").alias("bene_count"),
    col("Avg_Sbmtd_Chrg").cast("float").alias("submitted_charge"),
    col("Avg_Mdcr_Pymt_Amt").cast("float").alias("medicare_payment"),
    col("Rndrng_Prvdr_State_Abrvtn").alias("state"),
    col("Place_Of_Srvc").alias("place_of_svc"),
    lit(2021).alias("year")
)

print("Loading NPI registry...")
npi_reg = spark.read.option("header", True)     .csv("hdfs://namenode:9000/medicare/raw/nppes_npi.csv")     .select(
        col("npi").alias("npi_reg_npi"),
        col("specialty"),
        col("entity_type")
    )

print("Joining datasets...")
enriched = billing_typed.join(
    npi_reg,
    billing_typed.npi == npi_reg.npi_reg_npi,
    "left"
)

final = enriched.select(
    "npi", "proc_code", "description",
    "bene_count", "submitted_charge",
    "medicare_payment", "state", "year",
    "specialty", "entity_type"
)

print("Writing output to HDFS...")
final.write.mode("overwrite")     .option("sep", "	")     .csv("hdfs://namenode:9000/medicare/processed/")

count = final.count()
print("ETL complete. " + str(count) + " rows written to /medicare/processed/")
spark.stop()
